Libertine and LaTex

Because of some advantages over XeTex we reactivated our classical Libertine-Tex-package. It can be found here:
http://linuxlibertine.sourceforge.net/latex/

Of course, you are also free to use the innovative Tex-Variant “XeTex”, which supports Libertine directly plus its wonderful OpenType-features. You’ll find information about the use of Libertine with XeTex and the advantages of OpenType-support on our Website, here:

http://linuxlibertine.sf.net
